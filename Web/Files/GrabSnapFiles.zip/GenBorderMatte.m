function matte = GenBorderMatte(img, cut)
    warning('STUB! GenBorderMatte only returns the original cut.')
    matte = cut;
end